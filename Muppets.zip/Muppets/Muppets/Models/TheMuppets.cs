﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace Muppets.Models
{
    public class TheMuppets
    {
        public int ID{ get; set; }

        [Required(ErrorMessage = "Please Enter a Name")]
        public string Name{ get; set; }
        public int FirstAppearance { get; set; }
        [Required(ErrorMessage = "Please Enter a Profession")]
        public string Profession{ get; set; }
        public string Picture{ get; set; }
        public string VideoLink{ get; set; }

    }
}