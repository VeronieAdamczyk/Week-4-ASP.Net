﻿using Muppets.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Muppets.Controllers
{
    public class HomeController : Controller
    {

        public static List<TheMuppets> MuppetsList = new List<TheMuppets>();
        

        public ActionResult Populate()
        {
            for (int i = 0; i <10; i++)
            {

                string[] MuppetCharacters = { "Kermit", "Miss Piggy", "Gonzo", "Animal", "Swedish Chef","Beaker", "Scooter", "Fozzie Bear", "Sam the Eagle","Statler And Waldorf"};
                int[] MuppetAppearance = { 1955, 1976, 1976, 1975, 1975, 1977, 1977, 1976, 1976, 1975, 1975 };
                string[] MuppetProfession = { "Host", "Singer", "Daredevil performer", "Drummer", "Chef", "Lab Assistant", "Kermits Assistant", "Comedian", "Politial Commentator", "Profesional Complainers" };
                string[] MuppetPhoto = {"kermit","misspiggy","gonzo","animal", "swedishchef", "beaker", "scooter", "fozziebear", "samtheeagle", "statandwald"};
                
                TheMuppets one = new TheMuppets { ID = i, Name = MuppetCharacters[i], FirstAppearance = MuppetAppearance[i], Profession = MuppetProfession[i], Picture = "~/Content/" + MuppetPhoto[i] + ".jpg", VideoLink = "cOLg7Y1vLio" };
                AddToMuppetsList(one);
            }

            return RedirectToAction("Index");
            
            }

        public static List<TheMuppets> AddToMuppetsList (TheMuppets theMup)
        {
            MuppetsList.Add(theMup);

            return (MuppetsList);
        }



        public ActionResult Index()
        {
            return View(MuppetsList);
        }



        public ActionResult Details(int id)
        {
            var Muppet = MuppetsList.Single (m => m.ID == id);

            return View(Muppet);
        }


        //Edit Muppet 
        public ActionResult Edit(int id)
        {
            var Muppet = MuppetsList.Single(m => m.ID == id);

            return View(Muppet);
        }
        [HttpPost]


        public ActionResult Edit(int id, FormCollection collection)
        {
            if (!ModelState.IsValid)
            {
                return View();
            }

            try
            {
               
                var Muppet = MuppetsList.Single(m => m.ID == id);

                if (TryUpdateModel(Muppet))
                {
                  
                    
                    string theID = collection["ID"];
                    Muppet.ID = Int32.Parse(theID);
                    Muppet.Name = collection["Name"];
                    Muppet.Profession = collection["Profession"];

                    return RedirectToAction("Index");
                }
                return View(MuppetsList);
            }
            catch
            {
                return View();
            }
        }

        //Delete Muppet 
        public static List<TheMuppets> DeleteFromMuppetList(TheMuppets theMup)
        {
            MuppetsList.Remove(theMup);
            return (MuppetsList);
        }
        
        public ActionResult Delete(int? id)
        {

            //determines muppet to remove 
            var Muppet = MuppetsList.Single(m => m.ID == id);

           
            return View(Muppet);
        }

        
        [HttpPost]

        public ActionResult Delete(int id)
        {
            try
            {
                TheMuppets theMup = new TheMuppets();

             
               var Muppet = MuppetsList.Single(m => m.ID == id);

                //Pass Muppet to remove
                DeleteFromMuppetList(Muppet);

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }


    //Create Muppet
        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]

        public ActionResult Create(FormCollection collection)
        {
            if (ModelState.IsValid)
            {

                try
                {
                    
                    TheMuppets Muppet = new TheMuppets();
                    

                    string theID = collection["ID"];

                    Muppet.ID = Int32.Parse(theID);
                    Muppet.Name = collection["Name"];

                    string FirstAppearance = collection["FirstAppearance"];
                    Muppet.FirstAppearance = Int32.Parse(FirstAppearance);


                    string picture = collection["Picture"];
                    Muppet.Picture = picture;

                    
                    AddToMuppetsList(Muppet);

                    return RedirectToAction("Index");
                }
                catch
                {
                    return View();
                }
            }
            return View();
        }

    }
}